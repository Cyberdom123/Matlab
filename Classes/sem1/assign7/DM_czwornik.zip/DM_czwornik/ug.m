function u=ug(t,fo,p)
    u = sin(2*pi*fo*t + p);